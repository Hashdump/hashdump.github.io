import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs


TARGET_USERNAME = "hashdump"
TARGET_HASH = "3c5cb250897fcf87fcf9dd27a411bbc870b2fa4eb735676d64bf041a60b99b24"
SALT = "K2&C4m4b&aZ&Wq33"


class CustomRequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        # https://www.pythonfaq.net/how-to-handle-incoming-http-requests-with-basehttprequesthandler/
        content_length = int(self.headers.get('Content-Length', 0))
        content_type = self.headers.get('Content-Type', '')

        if content_type == 'application/x-www-form-urlencoded':
            post_data = self.rfile.read(content_length).decode('utf-8')
            params = parse_qs(post_data)

            username = params.get("username", [''])[0]
            password = params.get("password", [''])[0]
            salted_password = password + SALT

            pw_hash = hashlib.sha256(salted_password.encode('utf-8')).hexdigest()
            print("Hash:", pw_hash)

            if username == TARGET_USERNAME and pw_hash == TARGET_HASH:
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain')
                self.end_headers()
                self.wfile.write(b"Login successful\n")
            else:
                self.send_response(403)
                self.send_header('Content-Type', 'text/plain')
                self.end_headers()
                self.wfile.write(b"Incorrect username or password\n")

        else:
            self.send_response(415)
            self.end_headers()
            self.wfile.write(b'Unsupported Media Type\n')


def run():
    # Based on https://docs.python.org/3/library/http.server.html
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, CustomRequestHandler)
    httpd.serve_forever()


if __name__ == "__main__":
    run()
